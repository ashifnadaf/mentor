import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServicesService {
  url='https://jsonplaceholder.typicode.com/users'


  constructor(private http:HttpClient) { }
  getTodayDate=()=>{
      var today = new Date();
      return today
  }


  getdata(){
    return this.http.get(this.url)
  }
}
