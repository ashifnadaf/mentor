import { Component } from '@angular/core';
import { MyServicesService } from './my-services.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'mentor';
  today : Date;
  data;

  homeactive = false;
  aboutactive = false;
  coursesactive = false
  trainersactive = false
  eventsactive = false
  pricingactive = false
  contactactive = false

  constructor( private myservice :MyServicesService) {
    this.today = myservice.getTodayDate()

    this.data =myservice.getdata();
  }


  menuclicked(clickedon :String)
  {
    this.homeactive = false
    this.aboutactive = false
    this.coursesactive = false
    this.trainersactive = false
    this.eventsactive = false
    this.pricingactive = false
    this.contactactive = false


    if(clickedon == "home"){
      this.homeactive =true;
    }

    else if (clickedon == "about") {
      this.aboutactive = true;
    }
    else if (clickedon == "courses"){
      this.coursesactive = true;
    }

    else if (clickedon == "trainers"){
      this.trainersactive = true;
    }

    else if(clickedon =="events"){
      this.eventsactive = true;
    }

    else if(clickedon == "pricing"){
      this.pricingactive = true;
    }
    else if(clickedon == "contact"){
      this.contactactive = true;
    }

  }
}
